a=int(input("Enter First number"))
b=int(input("Enter Second number"))
c=int(input("Enter third number "))
if a>b and a>c:
  print("a is greater")
elif b>a and b>c:
  print("b is greater")
elif c>b and c>a:
  print("c is greater")
else:
  print("All three no are equal")
"""Input1:
Enter First number: 50
Enter Second number: 30
Enter Third number: 20
Output1:
a is greater
Input2:
Enter First number: 10
Enter Second number: 40
Enter Third number: 25
Output2:
b is greater
Input3:
Enter First number: 22
Enter Second number: 25
Enter Third number: 30
Output3:
c is greater
Input4:
Enter First number: 15
Enter Second number: 15
Enter Third number: 15
Output4:
All three no are equal"""
