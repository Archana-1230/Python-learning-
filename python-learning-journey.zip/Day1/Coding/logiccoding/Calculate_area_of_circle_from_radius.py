#Program to calculate the area of a circle from the radius

r=int(input("Enter the radius of the circle:"))
π=3.14
print("Area of the circle:",π*(r**2))
"""
Input:
Enter the radius of the circle: 7
Output:
Area of the circle is: 153.94
Explanation:
The formula for the area of a circle is:Area = π × r²
"""

