MCQs
Q1. What will be the output of print(type(10.5))?
A) <class 'int'>
B) <class 'float'> ✅
C) <class 'double'>
D) float
Q2. What is the result of input("Enter name: ")?
A) String ✅
B) Integer
C) Float
D) None
Q3. Which is a valid variable name?
A) 2x
B) _num ✅
C) @name
D) first-name
Q4. What is the default type returned by input()?
A) int
B) str ✅
C) float
D) bool
Q5. Which of the following is used for comments?
A) //
B) /* */
C) # ✅
D) <!-- -->
